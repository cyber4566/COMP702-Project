**NB**
Project is developed in PyCharm

STEP 1:
Run the Preprocessing.py file

STEP 2:
Run the Segmentation.py file

STEP 3:
Run the Feature Extraction_Hu.py file

STEP 4:
Run the Feature Extraction_GLCM.py file

STEP 5:
Run the KNN_Classifier.py file or the LSTM_classifier.py

A prompt will come up asking if you want to use the Haralick features as training data.

Press Y if yes else press N.

If you press N, the system will automatically use the Hu moments as training data 